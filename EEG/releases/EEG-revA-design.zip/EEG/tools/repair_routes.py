"""Route the two SES import gaps; final correctness is checked by KiCad DRC."""
import heapq
import math
from pathlib import Path
import numpy as np
import pcbnew

BASE = Path(__file__).resolve().parents[1] / "hardware"
board = pcbnew.LoadBoard(str(BASE/'EEG.kicad_pcb'))
step = 0.05
x0, y0, x1, y1 = 28., 40., 80., 95.
nx, ny = round((x1-x0)/step)+1, round((y1-y0)/step)+1
layers = (pcbnew.F_Cu, pcbnew.B_Cu)
def mm(p): return pcbnew.ToMM(p)
def xy(p): return mm(p.x), mm(p.y)

def masks(netname, radius):
    blocked = np.zeros((2, ny, nx), dtype=bool)
    def paint(cx, cy, extent, test, ls):
        i0=max(0, math.floor((cx-extent-x0)/step)); i1=min(nx, math.ceil((cx+extent-x0)/step)+1)
        j0=max(0, math.floor((cy-extent-y0)/step)); j1=min(ny, math.ceil((cy+extent-y0)/step)+1)
        if i0>=i1 or j0>=j1:return
        X=x0+np.arange(i0,i1)[None,:]*step
        Y=y0+np.arange(j0,j1)[:,None]*step
        mask=test(X,Y)
        for l in ls:blocked[l,j0:j1,i0:i1] |= mask
    for fp in board.GetFootprints():
        for p in fp.Pads():
            if p.GetNetname()==netname:continue
            ls=[i for i,l in enumerate(layers) if p.IsOnLayer(l)]
            if not ls:continue
            cx,cy=xy(p.GetPosition()); w,h=xy(p.GetSize()); a=math.radians(p.GetOrientationDegrees())
            margin=.2+radius+.01
            extent=math.hypot(w,h)/2+margin
            def hit(X,Y,cx=cx,cy=cy,w=w,h=h,a=a,margin=margin):
                dx=X-cx;dy=Y-cy
                u=dx*math.cos(a)-dy*math.sin(a);v=dx*math.sin(a)+dy*math.cos(a)
                # Rectangle expansion with rounded corners, conservative for roundrects.
                return np.maximum(abs(u)-w/2,0)**2+np.maximum(abs(v)-h/2,0)**2 < margin**2
            paint(cx,cy,extent,hit,ls)
    for t in board.GetTracks():
        if t.GetNetname()==netname:continue
        width=t.GetWidth(pcbnew.F_Cu) if isinstance(t,pcbnew.PCB_VIA) else t.GetWidth()
        margin=.2+radius+.01+mm(width)/2
        if isinstance(t,pcbnew.PCB_VIA):
            cx,cy=xy(t.GetPosition())
            paint(cx,cy,margin,lambda X,Y,cx=cx,cy=cy,r=margin:(X-cx)**2+(Y-cy)**2<r*r,(0,1))
        else:
            ax,ay=xy(t.GetStart());bx,by=xy(t.GetEnd());dx=bx-ax;dy=by-ay
            length2=dx*dx+dy*dy
            ls=[i for i,l in enumerate(layers) if t.GetLayer()==l]
            def hit(X,Y,ax=ax,ay=ay,dx=dx,dy=dy,length2=length2,r=margin):
                u=np.clip(((X-ax)*dx+(Y-ay)*dy)/max(length2,1e-20),0,1)
                return (X-ax-u*dx)**2+(Y-ay-u*dy)**2<r*r
            paint((ax+bx)/2,(ay+by)/2,math.sqrt(length2)/2+margin,hit,ls)
    return blocked

def route(name, source, target):
    blocked=masks(name,.1); vb=masks(name,.3).any(axis=0)
    def node(p):return (0,round((p[1]-y0)/step),round((p[0]-x0)/step))
    start,goal=node(source),node(target)
    assert not blocked[start] and not blocked[goal], (name,'blocked endpoint',blocked[start],blocked[goal])
    def heuristic(p):return math.hypot(p[1]-goal[1],p[2]-goal[2])+(10 if p[0]!=goal[0] else 0)
    queue=[(heuristic(start),0,start)];cost={start:0};parent={}
    steps=[(dy,dx,math.hypot(dx,dy)) for dy in (-1,0,1) for dx in (-1,0,1) if dy or dx]
    while queue:
        _,g,p=heapq.heappop(queue)
        if g!=cost.get(p):continue
        if p==goal:break
        l,j,i=p
        neighbors=[]
        for dj,di,dist in steps:
            jj,ii=j+dj,i+di
            if 0<=jj<ny and 0<=ii<nx and not blocked[l,jj,ii]:
                if dj and di and (blocked[l,jj,i] or blocked[l,j,ii]):continue
                neighbors.append(((l,jj,ii),dist))
        if not vb[j,i]:neighbors.append(((1-l,j,i),25.))
        for n,d in neighbors:
            ng=g+d
            if ng<cost.get(n,float('inf')):
                cost[n]=ng;parent[n]=p;heapq.heappush(queue,(ng+heuristic(n),ng,n))
    else:
        print('reachable',name,len(cost),min(p[2] for p in cost),max(p[2] for p in cost),min(p[1] for p in cost),max(p[1] for p in cost), 'vias',sum(not vb[p[1],p[2]] for p in cost),flush=True)
        raise RuntimeError('No path for '+name)
    path=[goal]
    while path[-1]!=start:path.append(parent[path[-1]])
    path.reverse()
    # Keep bends and layer transitions, collapsing straight grid runs.
    compact=[path[0]]
    for k in range(1,len(path)-1):
        a,b,c=path[k-1:k+2]
        if tuple(b[q]-a[q] for q in range(3)) != tuple(c[q]-b[q] for q in range(3)):compact.append(b)
    compact.append(path[-1])
    points=[(l,x0+i*step,y0+j*step) for l,j,i in compact]
    points.insert(0,(0,*source));points.append((0,*target))
    net=board.FindNet(name)
    for a,b in zip(points,points[1:]):
        if a[0]!=b[0]:
            v=pcbnew.PCB_VIA(board);v.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(a[1]),pcbnew.FromMM(a[2])));v.SetWidth(pcbnew.FromMM(.6));v.SetDrill(pcbnew.FromMM(.3));v.SetViaType(pcbnew.VIATYPE_THROUGH);v.SetLayerPair(*layers);v.SetNetCode(net.GetNetCode());board.Add(v)
        elif a[1:]!=b[1:]:
            t=pcbnew.PCB_TRACK(board);t.SetStart(pcbnew.VECTOR2I(pcbnew.FromMM(a[1]),pcbnew.FromMM(a[2])));t.SetEnd(pcbnew.VECTOR2I(pcbnew.FromMM(b[1]),pcbnew.FromMM(b[2])));t.SetWidth(pcbnew.FromMM(.2));t.SetLayer(layers[a[0]]);t.SetNetCode(net.GetNetCode());board.Add(t)
    print(name, 'route segments',len(points)-1, 'via count',sum(a[0]!=b[0] for a,b in zip(points,points[1:])),flush=True)

def pad(ref,pin):
    return xy(next(p.GetPosition() for f in board.GetFootprints() if f.GetReference()==ref for p in f.Pads() if p.GetNumber()==str(pin)))
for ch in (4,3,2,1):
    route(f'CH{ch}_N',pad('U1',17-2*ch),pad(f'C{ch}',2))
    route(f'CH{ch}_ADC',pad('U1',18-2*ch),pad(f'C{ch}',1))
for ch,r in ((4,38),(3,36),(2,34),(1,10)):
    route(f'CH{ch}_N',pad(f'R{r}',2),pad(f'C{ch}',2))
    route(f'CH{ch}_ADC',pad(f'R{2*ch}',2),pad(f'C{ch}',1))
route('A5V',(40.1291,63.0166),(50.9688,65.9188))
pcbnew.ZONE_FILLER(board).Fill(board.Zones())
pcbnew.SaveBoard(str(BASE/'EEG.kicad_pcb'),board)
