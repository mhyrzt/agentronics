"""Store the intentional footprint variants in a portable project library."""
from copy import deepcopy
import json
from pathlib import Path
from build_schematic import String, children, dump, parse

base = Path(__file__).resolve().parents[1] / "hardware"
board = parse((base/'EEG.kicad_pcb').read_text())
library = base/'EEG_Footprints.pretty'
library.mkdir(exist_ok=True)
for fp in children(board, 'footprint'):
    ref = next(str(p[2]) for p in children(fp, 'property') if p[1] == 'Reference')
    if ref != 'U2' and not ref.startswith('MH'):
        continue
    name = 'ESP32-C3-WROOM-02_EdgeAntenna' if ref == 'U2' else 'MountingHole_3.2mm_M3'
    fp[1] = String('EEG_Footprints:'+name)
    template = deepcopy(fp)
    origin = children(fp, 'at')[0]
    # Footprint keepout vertices are absolute in a board, local in a library.
    for zone in children(template, 'zone'):
        for polygon in children(zone, 'polygon'):
            for pts in children(polygon, 'pts'):
                for xy in children(pts, 'xy'):
                    xy[1] = round(float(xy[1])-float(origin[1]), 6)
                    xy[2] = round(float(xy[2])-float(origin[2]), 6)
    template[1] = String(name)
    template.insert(2, ['version', '20241229'])
    template.insert(3, ['generator', String('pcbnew')])
    for node in template[:]:
        if isinstance(node, list) and node and node[0] in ('at', 'uuid', 'path', 'sheetname', 'sheetfile'):
            template.remove(node)
    for prop in children(template, 'property'):
        if prop[1] == 'Reference':
            prop[2] = String('REF**')
    for pad in children(template, 'pad'):
        for node in pad[:]:
            if isinstance(node, list) and node and node[0] in ('net', 'pinfunction', 'pintype'):
                pad.remove(node)
    (library/(name+'.kicad_mod')).write_text(dump(template)+'\n')
(base/'EEG.kicad_pcb').write_text(dump(board)+'\n')
(base/'fp-lib-table').write_text('(fp_lib_table\n (version 7)\n (lib (name "EEG_Footprints")(type "KiCad")(uri "${KIPRJMOD}/EEG_Footprints.pretty")(options "")(descr "Project antenna graphics and mounting holes"))\n)\n')
manifest = json.loads((base/'design-manifest.json').read_text())
for c in manifest:
    if c['reference'] == 'U2':
        c['footprint'] = 'EEG_Footprints:ESP32-C3-WROOM-02_EdgeAntenna'
(base/'design-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
p = base/'sym-lib-table'
s = p.read_text().replace('/usr/share/kicad/symbols/', '${KICAD9_SYMBOL_DIR}/')
s = s.replace(str(base)+'/EEG_Custom.kicad_sym', '${KIPRJMOD}/EEG_Custom.kicad_sym')
p.write_text(s)
