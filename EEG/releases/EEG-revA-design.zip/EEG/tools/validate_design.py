"""Compare exported schematic nets, PCB pads and BOM; no board mutation."""
import csv
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from build_schematic import children, parse

base = Path(__file__).resolve().parents[1]
xml = ET.parse(base/'exports/EEG.net').getroot()
expected = {}
for net in xml.findall('./nets/net'):
    for n in net.findall('node'):
        expected[(n.attrib['ref'], n.attrib['pin'])] = net.attrib['name']
components = {c.attrib['ref']: c for c in xml.findall('./components/comp')}
board = parse((base/'hardware/EEG.kicad_pcb').read_text())
seen = set()
errors = []
pad_count = 0
footprints = {}
for fp in children(board, 'footprint'):
    props = {str(p[1]): str(p[2]) for p in children(fp, 'property')}
    ref = props['Reference']
    if ref.startswith('MH'):
        continue
    footprints[ref] = str(fp[1])
    for p in children(fp, 'pad'):
        pin = str(p[1])
        if not pin:
            continue  # Unnumbered solder-paste apertures in the module footprint.
        pad_count += 1
        key = ref, pin
        seen.add(key)
        nets = children(p, 'net')
        actual = str(nets[0][2]) if nets else ''
        want = expected.get(key)
        if want != actual:
            errors.append({'pad': key, 'schematic': want, 'pcb': actual})
for key in expected.keys()-seen:
    errors.append({'missing_pcb_pad': key})
for ref,c in components.items():
    if c.findtext('footprint') != footprints.get(ref):
        errors.append({'footprint_mismatch': ref})
bom = list(csv.DictReader((base/'exports/BOM.csv').open()))
quantity = sum(int(r['Quantity']) for r in bom)
if quantity != len(components):
    errors.append({'bom_quantity': quantity, 'schematic_components': len(components)})
if any(not r['MPN'] or not r['Manufacturer'] for r in bom):
    errors.append({'incomplete_bom_fields': True})
baseline=json.loads((base/'reports/baseline-net-map.json').read_text())
net_changes=[{'pin':ref+':'+pin,'before':baseline.get(ref+':'+pin),'after':net} for (ref,pin),net in expected.items() if baseline.get(ref+':'+pin)!=net]
if net_changes:
    errors.append({'readability_net_changes':net_changes})
drc = json.loads((base/'reports/final-drc.json').read_text())
for field in ('violations', 'unconnected_items', 'schematic_parity'):
    if drc[field]:
        errors.append({'drc_field': field, 'count': len(drc[field])})
result = {
    'passed': not errors,
    'electrical_components': len(components),
    'electrical_footprints': len(footprints),
    'numbered_electrical_pad_instances': pad_count,
    'unique_schematic_pins': len(expected),
    'bom_grouped_lines': len(bom),
    'bom_total_quantity': quantity,
    'readability_net_changes': len(net_changes),
    'errors': errors,
    'scope': 'CAD connectivity and metadata only; no assembled electrical validation',
}
(base/'reports/connectivity-audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['passed'] else 1)
