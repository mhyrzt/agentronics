# Building a four-channel EEG: from electrodes to wireless samples

An EEG board has an unusual job: preserve a very small voltage difference while its own processor, radio and power supply are doing comparatively noisy work. Understanding this board starts with that tension. The ADC needs quiet inputs and a stable reference; the radio needs bursts of current; the battery has a voltage that changes as it discharges. Each circuit exists to manage part of that problem.

This README walks through **Revision A**, a four-channel, battery-powered learning prototype built in KiCad 9. The PCB is 100 × 80 mm with two copper layers. You can follow the explanation alongside the [five-page schematic](exports/schematic.pdf) and use the component references, such as **R1** or **U1**, to find the actual parts.

**Current status:** the schematic and routed PCB pass CAD checks, but the board has not been assembled or electrically tested. Firmware is still to be written. The explanations below describe design intent and calculations, not measured performance or qualification for connection to a person. Start with simulated signals on the bench.

Read in order to follow the circuit, or jump to [inputs](#why-the-inputs-contain-more-than-a-wire), [ADC support](#why-use-a-dedicated-adc-instead-of-the-processors-adc), [bias](#why-there-is-a-separate-bias-circuit), [power](#two-supply-rails-two-different-priorities), [radio](#the-radio-is-also-the-acquisition-coordinator), [bench bring-up](#bringing-the-board-to-life-on-the-bench) or [project files](#find-the-design-files-and-open-them).

If you are new to schematics, **R** means resistor, **C** capacitor, **D** diode, **U** integrated circuit/module, **J** connector, **L** inductor, **F** fuse and **SW** switch. The following number identifies that particular part; it does not describe its value. For example, R1 is a 10 kΩ resistor. Net names such as `CH1_ADC` identify electrical connections even when the drawing does not show a continuous wire between pages.

## Start with the journey of one sample

Suppose channel 1's electrode voltage changes relative to the reference electrode. That difference passes through the input network, reaches the ADC, becomes a signed digital sample, and eventually leaves the radio as part of a packet. The processor handles the packets; the ADS1299 performs the analog acquisition.

```mermaid
flowchart LR
    E["CH1–CH4 electrodes + REF"] --> I["Input resistors, clamps and filters"]
    I --> A["U1 ADS1299-4\nGain + simultaneous conversion"]
    A -->|"SPI samples; DRDY timing"| M["U2 ESP32-C3\nBuffer and packetize"]
    M -->|"BLE — firmware pending"| H["Receiver\nDisplay and analysis"]
    A --> B["Bias amplifier + R11/R12"]
    B -->|"BIAS electrode"| E
```



[![Schematic overview showing the Inputs, Frontend, Power and Radio sheets](exports/previews/EEG.png)](exports/previews/EEG.svg)

*The actual KiCad overview page maps the same functional blocks. Click the image for the vector version.*

The schematic pages follow the same division: **Inputs** prepares the electrode signals, **Frontend** contains the ADC and its support circuits, **Power** generates the supply rails, and **Radio** contains the processor and programming interface. The root page is the map between them.

## What does a channel actually measure?

A voltage is always measured between two points. In this board, each ADC channel receives a positive input and a negative input:

$$
V_{\mathrm{diff},i}
= V\!\left(\mathrm{CH}i\_\mathrm{ADC}\right)
- V\!\left(\mathrm{CH}i\_\mathrm{N}\right),
\qquad i \in \{1,2,3,4\}
$$

Each channel's signed digital sample represents this differential voltage, scaled by the configured gain and ADC reference.

The four negative inputs originate at the same external **REF** electrode, but each has its own resistor/clamp branch. This is a shared-reference arrangement: the board measures four electrode-to-reference differences. It does not provide four separately accessible negative-electrode connections. Interference or movement at REF can therefore appear in several channels at once.

As a thought experiment, 2.500010 V at one input and 2.500000 V at the other produce a differential voltage of just 10 µV, despite both inputs sitting near 2.5 V. This is why the board needs both precise differential measurement and control of the average input voltage. These are illustrative numbers, not electrode voltages measured on this board.

Three different kinds of “reference” appear in this project. Keeping them distinct makes the rest of the schematic easier to read.

| Name | What it does here |
|---|---|
| **REF electrode** | The external comparison point for the four signal measurements. |
| **ADC voltage reference, VREFP/VREFN** | Sets the conversion scale: how analog voltage becomes a digital number. |
| **BIAS electrode** | Carries the bias amplifier's driven output, intended to help control input common-mode voltage. |
| **GND** | The electronics' shared supply return. It is not an electrode pin on J1. |

Differential voltage and **common-mode voltage** are also different. If both ADC inputs rise by the same amount, their difference stays constant, but their average voltage rises. A differential ADC can reject much of that shared disturbance only while both inputs remain within their allowed operating range. Biasing and electrode impedance matter even when the desired difference is tiny.

## Why the inputs contain more than a wire

Open the **Inputs** sheet and trace channel 1. The following is a simplified electrical view; the clamp symbols stand for the paired diodes connected to GND and A5V.

```text
CH1 electrode ── R1 10k ──●── R2 10k ──●── CH1_ADC / ADC IN1P
                         │             │
                    D1 rail clamp      │
                                       C1 4.7nF
REF electrode ── R9 10k ──●── R10 10k ─●── CH1_N   / ADC IN1N
                         │
                    D5 rail clamp
```



[![Annotated channel 1 schematic with resistor stages, BAV199 clamps and C1](exports/previews/input-channel.png)](exports/previews/input-channel.svg)

*Inputs sheet, callout I1: trace CH1_E and REF_E through the two branches to the ADC pair. Click the image for the vector version.*


<details>
<summary>Open the full annotated Inputs schematic page</summary>

[![Annotated Inputs schematic](exports/previews/EEG-Inputs.png)](exports/previews/EEG-Inputs.svg)

</details>

The signal still reaches the ADC through resistors. The diodes sit on branches, and C1 connects across the two ADC inputs. Those positions explain their jobs.

### The resistors limit current, but they have a cost

R1 and R9 sit between the external connector and the clamp nodes. They reduce the current that can flow toward a conducting clamp during an excursion. R2 and R10 add resistance between those nodes and the ADC and participate in the differential filter.

Increasing resistance is not a free improvement. It also adds thermal noise, increases the offset caused by leakage current, and changes the response when combined with electrode impedance and capacitance. The two 10 kΩ resistors per branch are this revision's starting choice, to be evaluated on the bench. These networks are not certified patient, defibrillator or ESD protection.

The same pattern repeats across all four channels:

| Channel | Positive branch | Reference branch | Clamps | Differential capacitor |
|---|---|---|---|---|
| 1 | R1, R2 | R9, R10 | D1, D5 | C1 |
| 2 | R3, R4 | R33, R34 | D2, D7 | C2 |
| 3 | R5, R6 | R35, R36 | D3, D8 | C3 |
| 4 | R7, R8 | R37, R38 | D4, D9 | C4 |

### Why BAV199 diodes?

Normally the clamp diodes should contribute very little current to the input. Leakage matters because current through an impedance produces a voltage error: $V_{\mathrm{error}} = I_{\mathrm{leak}} R$. For example:

$$
V_{\mathrm{error}}
= (1\,\mathrm{nA})(20\,\mathrm{k\Omega})
= 20\,\mathrm{\mu V}
$$
 That is an illustrative calculation, not a prediction of this board's leakage.

BAV199 is chosen for its low leakage. Each package contains two series-connected diodes, with their shared junction accessible at pin 3. Here, pin 1 goes to GND, pin 2 to A5V, and pin 3 to the clamp node. A large excursion can forward-bias one diode toward the corresponding rail. This is a leakage-conscious clamp choice, not a guarantee of transient survival; the rails also need to accommodate injected current. See [Nexperia's BAV199 data sheet](https://assets.nexperia.com/documents/data-sheet/BAV199.pdf).

### Why put C1 between the inputs?

C1–C4 provide a path for higher-frequency **differential** disturbances between the positive and negative inputs. Using one capacitor across the pair also avoids making this circuit depend on matching two separate capacitors to ground. It does not eliminate common-mode interference.

For a simplified small-signal model, with nonconducting clamps and negligible external source impedance, the resistance seen by C1 is the sum of both branches:

$$
\begin{aligned}
R_{\mathrm{diff}}
&= (10 + 10 + 10 + 10)\,\mathrm{k\Omega}
= 40\,\mathrm{k\Omega} \\
C_{\mathrm{diff}} &= 4.7\,\mathrm{nF} \\
f_c &\approx \frac{1}{2\pi R_{\mathrm{diff}} C_{\mathrm{diff}}} \\
&= \frac{1}{2\pi (40\times10^3)(4.7\times10^{-9})}\,\mathrm{Hz}
\approx 847\,\mathrm{Hz}
\end{aligned}
$$

This pole is well above the proposed 0.5–40 Hz application band. It is an input high-frequency attenuation stage, not the finished EEG bandpass or a complete anti-aliasing guarantee. Electrode impedance and parasitics change the actual response. The ADC's conversion/decimation behavior and later firmware filtering must be considered together.

C0G dielectric was selected for C1–C4 to keep the filter capacitance relatively stable. The larger supply capacitors use other dielectrics because their job is storing and delivering charge rather than setting this small-signal filter value.

## Why use a dedicated ADC instead of the processor's ADC?

**U1, ADS1299-4PAG**, combines four simultaneous conversion channels with programmable gain, a voltage reference, test facilities and a bias amplifier. That integration lets this project focus on electrode interfaces, supplies, layout and acquisition software rather than designing a separate precision amplifier chain for each channel. The four-channel variant matters: its pin usage and sample format must match the firmware. See the [TI ADS1299 family data sheet](https://www.ti.com/lit/ds/symlink/ads1299.pdf).



[![Annotated ADS1299 core schematic and its input and control nets](exports/previews/adc-core.png)](exports/previews/adc-core.svg)

*Frontend sheet, F1: the input pairs enter U1 at left; control and sample-transfer signals are at right. Click the image for the vector version.*

A **24-bit** output is a number format, not a promise of 24 useful bits of accuracy. Noise, offsets, gain error, the voltage reference and the input circuit determine what changes can actually be resolved. Likewise, programmable gain magnifies electrode offsets along with the wanted signal; using maximum gain immediately can cause clipping.

For that reason, initial firmware should use a modest gain, check raw offsets and saturation, and test known signals before choosing its operating gain. A smooth-looking plotted trace is weak evidence if the raw samples are already clipped or missing.

### Why all the capacitors around U1?

Some support the chip's internal circuits; others keep its external supplies locally steady. Their identical capacitor symbols hide very different responsibilities.

| Parts | Connection / purpose in this board |
|---|---|
| C6, 100 µF | VCAP1 support capacitor; polarized tantalum, positive at VCAP1. |
| C7, 1 µF | VCAP2 support capacitor. |
| C8, 1 µF, and C9, 100 nF | VCAP3 support capacitors. |
| C10, 1 µF | VCAP4 support capacitor. |
| C11, 10 µF, and C12, 100 nF | Bypass the conversion reference between VREFP and VREFN/GND. |
| C13–C17, 1 µF each | Local analog-supply bypass at the ADC supply groups. |
| R14, 0 Ω, and C18, 1 µF | Feed and bypass the separate A5V_CP supply branch. |
| C19, 10 µF, and C20, 100 nF | Additional analog-rail bulk/local bypass. |
| C21, 1 µF, and C22, 100 nF | Bypass the ADC's 3.3 V digital supply. |



[![Annotated reference and VCAP support capacitors](exports/previews/adc-support.png)](exports/previews/adc-support.svg)

*Frontend sheet, F2: VCAP networks and the VREFP bypass are different support circuits. Click the image for the vector version.*


<details>
<summary>Open the full annotated Frontend schematic page</summary>

[![Annotated Frontend schematic](exports/previews/EEG-Frontend.png)](exports/previews/EEG-Frontend.svg)

</details>

The VCAP and reference values follow the device's single-supply application circuit; treat those pins according to their specified function rather than as spare power outputs. Local bypass capacitors give changing load currents a short path. A capacitor far away, connected through a long inductive route, cannot serve that job equally well.

R14 is a deliberate removable link. A zero-ohm resistor conducts like a connection but leaves an assembly point for isolating the branch or evaluating a future modification. It does not filter noise by itself.

### Hardware defaults keep startup understandable

The processor takes time to boot. Pull resistors give the ADC's control pins defined levels during that interval: R21/R22 hold RESET/START low, R23 holds chip select high, and R19/R20 select the internal clock and hold PWDN high. R15–R18 define the unused ADC GPIO inputs.

Firmware must then deliberately initialize the ADC. The unused SRB reference switches remain disabled because this board routes its reference through four external branches. Clock output stays disabled because the external clock pin is grounded. Changing register settings can make correctly wired hardware behave incorrectly.

## Why there is a separate bias circuit

A signal can have a small differential voltage and still sit at an unsuitable common-mode voltage. The bias circuit addresses that separate problem. Its intended behavior is a feedback loop: observe selected channel common-mode information, generate a corrective output, and couple that output through the BIAS electrode path.

```text
Selected input common-mode information
                  │
                  v
       ADS1299 internal bias amplifier
                  │ BIAS_OUT
                  ├── R11 499k ── R12 499k ── BIAS electrode
                  │
                  └── [ R13 1M || C5 1nF ] ── BIAS_INV
                              feedback
```



[![Annotated bias amplifier parallel resistor and capacitor feedback](exports/previews/bias-feedback.png)](exports/previews/bias-feedback.svg)

*Frontend sheet, F3: R13 and C5 share both endpoints, forming the parallel feedback network. Click the image for the vector version.*

R13 and C5 are in parallel in the amplifier's feedback path. The resistor provides the resistive feedback path; the capacitor changes the loop's frequency response. Their RC frequency scale is:

$$
f_{\mathrm{RC}} = \frac{1}{2\pi R_{13} C_5}
= \frac{1}{2\pi (1\times10^6)(1\times10^{-9})}\,\mathrm{Hz}
\approx 159\,\mathrm{Hz}
$$

**That is not a measured closed-loop bandwidth**: the channel sensing configuration, amplifier behavior and external electrode/load network also affect the loop.

R11 and R12 total 998 kΩ in series with the driven output, limiting current for a given voltage difference. Having two resistors leaves resistance if one is shorted, but this observation is not a safety qualification. The feedback returns from BIAS_OUT before those resistors; the external electrode path must still be evaluated with a simulated load.

This revision uses the ADC's internal bias reference. BIASREF and unused BIASIN are grounded. Enable the amplifier only after verifying the configuration and checking stability. REF is a measurement input; BIAS is an actively driven output. They are not interchangeable connector pins.

## Two supply rails, two different priorities

The board's analog circuits need a 5 V rail, while the processor and digital interface use 3.3 V. A protected 2S lithium-ion pack provides the input headroom for both. Its proposed operating range here is 6.4–8.4 V; voltage falls with discharge and under load.

```mermaid
flowchart TD
    BAT["J2: protected 2S battery"] --> F["F1: resettable PTC"]
    F --> D["D6: reverse-polarity diode"]
    D --> J["J4: removable power shunt"]
    J --> SW["BAT_SW"]
    SW --> BUCK["U3 AP63203 + L1\nSwitching buck"]
    BUCK --> DV["3V3\nRadio + ADC digital supply"]
    SW --> LDO["U4 LP2985-N\nLinear regulator"]
    LDO --> AV["A5V\nADC analog supply + clamps"]
    SW --> SENSE["R31/R32 + C27\nBattery measurement"]
```

Both regulators share battery and ground connections. A separate analog regulator reduces reliance on the radio's 3.3 V rail; it does not provide galvanic isolation or guarantee that switching noise cannot reach the ADC.

### F1, D6 and J4: three different jobs



[![Annotated battery connector, fuse, polarity diode and power-enable shunt](exports/previews/battery-power.png)](exports/previews/battery-power.svg)

*Power sheet, P1: the battery passes through three separate functions before reaching BAT_SW. Click the image for the vector version.*

**F1**, a 0.75 A-hold PTC, increases resistance when sufficiently heated by excess current. Its response depends on current and temperature; it is not a precise 0.75 A electronic cutoff. The pack still requires its own protection.

**D6**, an SS14 Schottky diode, blocks a reversed battery connection in this series path. Its forward drop costs some voltage and dissipates heat. That loss needs to be included when checking regulator headroom at low battery voltage.

**J4** turns the downstream circuit on when a suitably rated shunt joins its two pins. Removing it disconnects BAT_SW, but the battery-side parts remain connected to the pack. Unplugging the pack is the master disconnect. There is no onboard charger: remove the pack for compatible offboard charging.

### Why the 3.3 V regulator switches

A linear regulator converting roughly 7.4 V to 3.3 V would turn the voltage difference into heat. As an illustration, at 100 mA:

$$
\begin{aligned}
P_{\mathrm{loss}} &\approx (V_{\mathrm{in}}-V_{\mathrm{out}}) I_{\mathrm{load}} \\
&= (7.4-3.3)\,\mathrm{V}\times0.1\,\mathrm{A}
= 0.41\,\mathrm{W}
\end{aligned}
$$

That is not a measured radio load. It explains the motivation for **U3, AP63203**, a fixed-3.3 V switching buck. Its switching stage transfers energy through **L1, 4.7 µH**, and the output capacitors. The tradeoff is switching ripple and fast current loops that need attention in layout and measurement. See the [AP63203 family data sheet](https://www.diodes.com/datasheet/download/AP63200-AP63201-AP63203-AP63205.pdf).



[![Annotated AP63203 buck regulator and support network](exports/previews/buck-supply.png)](exports/previews/buck-supply.svg)

*Power sheet, P2: identify the bootstrap capacitor, inductor, output capacitors and feedback connection. Click the image for the vector version.*

C28/C29 bypass its input. C30 is the bootstrap capacitor between BST and SW, supporting the high-side gate-drive circuit. C31/C32 store charge at the output, and FB senses the resulting 3.3 V rail. L1's saturation and current ratings provide design margin; a high inductor current rating does not mean the EEG board normally draws that current.

### Why the analog rail uses a linear regulator

**U4, LP2985-N**, makes A5V directly from BAT_SW. A linear regulator avoids adding another local switching node beside the analog circuit, at the cost of heat approximately proportional to voltage drop times load current. C33 bypasses its input, C34 bypasses its internal noise-related node, and C35/C36 support the output.



[![Annotated LP2985 analog regulator and bypass capacitors](exports/previews/analog-supply.png)](exports/previews/analog-supply.svg)

*Power sheet, P3: follow BAT_SW to the LDO and A5V; C34 and C35 serve different purposes. Click the image for the vector version.*


<details>
<summary>Open the full annotated Power schematic page</summary>

[![Annotated Power schematic](exports/previews/EEG-Power.png)](exports/previews/EEG-Power.svg)

</details>

The output capacitor is part of the regulator's stability system. TI documents different capacitance/ESR considerations for legacy and newer silicon; the installed device and effective ceramic capacitance must be checked rather than assuming any nominal 10 µF capacitor is suitable. Startup, load steps, ripple and oscillation are bench checks still to perform. See [TI's LP2985-N data sheet](https://www.ti.com/lit/ds/symlink/lp2985-n.pdf).

### Why capacitor voltage ratings exceed the rail voltage

A ceramic capacitor's printed value is not necessarily its capacitance in operation. DC bias, temperature and tolerance can reduce it, particularly for larger X5R/X7R values. The BOM uses voltage headroom, including 25 V parts for the 22 µF capacitors, to help manage this tradeoff. Actual effective capacitance still needs checking from the selected part's characteristics. The voltage rating alone does not prove the regulator will be stable.

## The radio is also the acquisition coordinator

**U2, ESP32-C3-WROOM-02-N4**, is a module rather than a bare radio chip. It bundles the processor, flash and RF implementation into a practical assembly choice. This project plans to use BLE for samples; the module's other capabilities do not imply they are used here. A module also does not qualify the complete board for a particular use. See [Espressif's module data sheet](https://documentation.espressif.com/esp32-c3-wroom-02_datasheet_en.html).



[![Annotated ESP32 module, reset network and boot straps](exports/previews/radio-control.png)](exports/previews/radio-control.svg)

*Radio sheet, R1/R2: acquisition-control nets reach the module while the EN and BOOT networks establish startup behavior. Click the image for the vector version.*


<details>
<summary>Open the full annotated Radio schematic page</summary>

[![Annotated Radio schematic](exports/previews/EEG-Radio.png)](exports/previews/EEG-Radio.svg)

</details>

The ADC's **DRDY** signal tells the processor that conversion data is ready. **SPI** transfers those samples using clock, chip-select and data lines. Sampling is time-sensitive; radio delivery can be delayed. A buffer between those tasks prevents a brief BLE delay from immediately becoming an acquisition failure, although it cannot make an undersized or overflowing buffer lossless.

```text
DRDY event → read ADC frame → bounded sample buffer → BLE packet → receiver
                 time-sensitive          radio timing can vary
```

R24–R26, 33 Ω, sit on the processor-driven SPI clock, data and chip-select lines. They are intended to damp fast-edge ringing. Their small resistance addresses signal integrity; it is unrelated to the large electrode current-limiting resistors.

C24/C25/C26 provide local 10 µF, 100 nF and 22 µF bypass/bulk capacitance for the module. Radio current changes can disturb the rail, so local charge storage and a short return path matter. They complement the regulator's output capacitors rather than replacing them.

### Why RESET and BOOT have their own small circuits

R27 and C23 give the module EN pin a pull-up and an RC startup delay; SW2 pulls it low for reset. R28–R30 define the GPIO9/8/2 boot-strap levels, and SW3 can pull GPIO9 low for download mode. Strap pins are read during startup, so they cannot be treated as unconstrained ordinary GPIOs when connecting external circuitry.

J3 exposes the bench UART and the reset/boot controls. Its 3.3 V pin is a rail sense/output, not an invitation to feed the board from a programmer. The connector table below gives the exact wiring and button sequence.

### Why the battery needs a divider

The processor must not see the full pack voltage on its ADC input. R31, 330 kΩ, and R32, 100 kΩ, divide BAT_SW down:

$$
\begin{aligned}
V_{\mathrm{BAT\_SENSE}}
&= V_{\mathrm{BAT}}\frac{R_{32}}{R_{31}+R_{32}} \\
&= V_{\mathrm{BAT}}\frac{100}{330+100}
= \frac{V_{\mathrm{BAT}}}{4.3} \\
V_{\mathrm{BAT\_SENSE}}\big|_{V_{\mathrm{BAT}}=8.4\,\mathrm{V}}
&\approx 1.95\,\mathrm{V} \\
I_{\mathrm{divider}}
&= \frac{V_{\mathrm{BAT}}}{R_{31}+R_{32}}
= \frac{8.4\,\mathrm{V}}{430\,\mathrm{k\Omega}}
\approx 19.5\,\mathrm{\mu A}
\end{aligned}
$$



[![Annotated R31 R32 battery divider and C27 filter](exports/previews/battery-monitor.png)](exports/previews/battery-monitor.svg)

*Radio sheet, R5: R31/R32 set the scale; C27 supplies local charge at the sense node. Click the image for the vector version.*

Large resistors keep the divider's continuous battery drain small. Their higher source impedance makes the measurement more sensitive to ADC loading and settling. C27, 100 nF, provides local charge and smooths fast changes; its nominal divider time constant, ignoring ADC loading, is:

$$
\tau = (R_{31}\parallel R_{32}) C_{27}
= \frac{(330\,\mathrm{k\Omega})(100\,\mathrm{k\Omega})}
{430\,\mathrm{k\Omega}}\times100\,\mathrm{nF}
\approx 7.7\,\mathrm{ms}
$$

ADC attenuation, calibration and acquisition timing still need verification.

This circuit **measures** battery voltage. It does not disconnect the battery. Firmware can stop acquisition at the proposed loaded-pack floor, but the regulators keep consuming current while J4 is fitted. Independent pack protection and physically disconnecting power remain separate responsibilities.

## The PCB is part of the circuit

A schematic shows connectivity; the PCB determines where currents actually flow. Input leakage can come from flux residue, interference can couple through nearby traces, and shared return paths can turn radio or regulator current into an unwanted analog voltage.

This revision uses two copper layers with ground pours and stitching vias. Its analog inputs, buck switching loop and antenna should be inspected with their different sensitivities in mind. Ground copper is useful, but it cannot by itself prove low-noise performance. The [top preview](exports/previews/pcb-top.png) is a useful map; open the routed board for layer-by-layer inspection.

The ESP32 antenna extends beyond the board's upper edge to preserve the intended antenna clearance. Keep the enclosure, battery, cables and metal away from that region. The custom footprint retains the module's pads and copper keepout while placing antenna graphics on the fabrication layer. Three mounting holes are mechanical, board-only features. Small component references mostly appear on F.Fab, so use the [assembly drawing](exports/assembly.pdf) for placement.

## What must software add?

The hardware ends at digitized samples and a programmable processor. Firmware must initialize the ADC, establish sample timing, detect saturation, track missing samples, measure battery voltage and send recoverable packets. The receiver then interprets those packets and applies the intended display/analysis filters.

The proposed starting point is **250 samples/s per channel**, with later 0.5–40 Hz filtering and selectable 50/60 Hz rejection. The channel-value payload alone is:

$$
\begin{aligned}
\text{Payload rate}
&= N_{\mathrm{channels}}\times\frac{N_{\mathrm{bits}}}{8}\times f_s \\
&= 4\times\frac{24}{8}\times250\,\mathrm{Hz}
= 3{,}000\,\mathrm{bytes/s}
\end{aligned}
$$

ADC status, timestamps and packet overhead add to that rate. Packet size, buffering and BLE behavior still need implementation and testing.

Keep raw acquisition and filtered display data distinguishable. A mains notch can reduce a visible interference line, but it cannot repair an ADC that clipped before the data reached software. The detailed GPIO mapping and initialization expectations follow.

## Connector and firmware reference

Pin numbers refer to CAD pad numbers, not a viewpoint-dependent cable order. Verify continuity before connecting a harness.

| Connector | Pin | Function |
|---|---:|---|
| J1, JST XH 6-pin | 1–4 | CH1, CH2, CH3, CH4 electrode |
| J1 | 5 | Common REF electrode |
| J1 | 6 | BIAS electrode; not circuit ground |
| J2, JST XH 2-pin | 1 | Protected battery positive |
| J2 | 2 | Battery negative / circuit GND |
| J4, 2.54 mm 2-pin | 1–2 | Fit a suitable shunt to enable power; remove to disconnect BAT_SW |
| J3, bench UART | 1 | GND |
| J3 | 2 | 3.3 V rail sense/output; do not connect an adapter's supply output |
| J3 | 3 | MCU UART TX → adapter RX |
| J3 | 4 | MCU UART RX ← adapter TX |
| J3 | 5 | MCU enable/reset |
| J3 | 6 | GPIO9 boot strap |

Use a **3.3 V logic** UART adapter, with only GND/TX/RX connected for ordinary programming. Hold SW3 (BOOT), press and release SW2 (RESET), then release BOOT for serial download. Disconnect all electrode cables for programming and wired measurements.

### Firmware interface — implementation pending

| ESP32 GPIO | Signal | Direction from MCU |
|---:|---|---|
| 4 | ADC_MISO | Input |
| 6 | ADC_SCLK through 33 Ω | Output |
| 7 | ADC_MOSI through 33 Ω | Output |
| 10 | ADC_CS through 33 Ω | Output |
| 3 | ADC_DRDY | Input / interrupt |
| 1 | ADC_RESET | Output |
| 0 | ADC_START | Output |
| 5 | VBAT_SENSE | Analog input |
| 2, 8, 9 | Boot straps | Preserve startup levels; GPIO9 is BOOT switch |

Use SPI mode 1, initially at a conservative 1 MHz, and honor all command/reset timing in the TI data sheet. External START and RESET are held low until firmware intentionally initializes the ADC. PWDN and CLKSEL are pulled high. Keep chip select high while resetting and send SDATAC before register access.

For initial configuration, select 250 samples/s, internal reference, internal clock, clock output disabled, SRB1/SRB2 disabled, and four normal differential channels. Start with modest PGA gain (for example 12) and confirm offsets do not saturate the input range. Explicitly configure the internal bias reference, power the bias buffer only after bench checks, and select appropriate bias sense channels. Disable lead-off excitation during the initial noise test. Do not rely on power-on register defaults.

Read the device ID and programmed registers back. Validate the **ADS1299-4** data-frame size against the data sheet; do not copy an eight-channel driver's frame length unchanged. Capture DRDY timestamps and signed 24-bit values, then stream through BLE with sample sequence numbers, battery voltage, saturation flags, and dropped-sample accounting. Use a bounded acquisition buffer so radio delays cannot block ADC service. Nominal application filtering is 0.5–40 Hz with selectable 50/60 Hz rejection, after verifying raw acquisition.

VBAT_SENSE uses 330 kΩ/100 kΩ and 100 nF: ideal battery voltage is $V_{\mathrm{BAT}} = 4.3\,V_{\mathrm{BAT\_SENSE}}$. At 8.4 V the ADC pin is about 1.95 V; choose appropriate attenuation and use ADC calibration. Stop acquisition and disable ADC activity when the loaded pack reaches the chosen 6.4 V operating floor; independent pack protection remains necessary. With the shunt fitted, regulators still consume current after software stops. Remove the shunt or unplug the pack for storage. The 6.4 V threshold is an operating target, not a measured protection guarantee.

## Bringing the board to life on the bench

1. Inspect soldering, polarity and connector numbering; check resistance between BAT_SW/GND, 3V3/GND and A5V/GND before applying power. Look for bridges on ADC and regulator pads. No electrode cable attached.
2. With no human connection, initially power from a current-limited bench source at approximately 7.4 V through J2. Establish expected idle current; a current limit alone does not prove correct operation. Check 3V3 against the module's 3.0–3.6 V range and A5V against the ADC's 4.75–5.25 V range.
3. Check startup, steady-state ripple and load-step response at local bypass capacitors with a short ground connection. Inspect the LDO output for oscillation; confirm effective output capacitance and ESR meet the relevant LP2985-N chip revision requirements. Check regulator and diode temperature.
4. Program over J3 with electrode leads disconnected. Read ADC ID, registers and DRDY; exercise internal test signals and verify gain/scaling and channel order. Confirm RESET/START startup behavior across repeated power cycles.
5. Use an isolated signal simulator or bench fixtures, never a person for this stage. Measure shorted-input noise and offsets. Then apply small differential sine waves around the appropriate analog common-mode voltage through representative source resistances. Check clipping, common-mode rejection, mains pickup and reference filter branches.
6. Enable and test the bias loop with a simulated electrode/load network. Verify stability, output range and resistor-chain continuity. Exercise detached electrodes and saturation, BLE reconnects, dropped packets and loaded-battery shutdown.
7. Repeat acquisition on the protected battery with all wired bench equipment disconnected. Independent safety and analog-performance review is required before considering recording on a person.


## Find the design files and open them

Open [hardware/EEG.kicad_pro](hardware/EEG.kicad_pro) in KiCad 9 or newer with the standard symbol and footprint libraries installed. Project libraries are included and use relative paths.

| If you want to… | Open… |
|---|---|
| Read the circuits without KiCad | [Five-page schematic PDF](exports/schematic.pdf) |
| Edit the design | [KiCad project](hardware/EEG.kicad_pro) |
| Inspect routing | [PCB](hardware/EEG.kicad_pcb) and [top preview](exports/previews/pcb-top.png) |
| Find exact parts | [BOM](exports/BOM.csv): 29 grouped lines, 95 electrical components |
| Assemble the board | [Assembly drawing](exports/assembly.pdf) and [placement CSV](exports/fabrication/positions.csv) |
| Review manufacturing outputs | [Gerbers and drills](exports/fabrication/) |
| Download the organized project | [Design ZIP](releases/EEG-revA-design.zip) |
| Review CAD check results | [ERC](reports/schematic-erc.rpt), [DRC](reports/final-drc.json), [connectivity audit](reports/connectivity-audit.json) |

## Fabrication and assembly details

Specify two layers, 1.6 mm FR-4, 35 µm copper, solder mask on both sides, and 0.20 mm trace/space capability. Routing vias are 0.60/0.30 mm; the module footprint also has **0.20 mm plated thermal holes**, so confirm drill capability with the fabricator. The board outline is 100 × 80 mm; the antenna overhang increases the assembled envelope.

Assembly includes an exposed-pad radio module, a 0.5 mm-pitch TQFP ADC and small regulators. Reflow/stencil assembly is preferable. Check the polarity of C6, D6 and J2, and verify connector numbering against the assembly drawing. Clean flux around high-impedance analog inputs: residue can introduce leakage and offsets.

External accessories are not in the PCB BOM: a commercially protected/balanced 2S pack with matching polarized lead, compatible offboard charger, a rated J4 shunt, electrode connector housing/crimps, simulator cables and three nonconductive mounting spacers. Cost and supplier availability have not been verified.

## What the checks prove, and what remains to learn

ERC checks schematic rules such as pin connections. DRC checks board rules such as spacing and unconnected copper, and schematic parity compares the board with the schematic. A separate audit compares every numbered electrical PCB pad with the exported netlist and checks BOM quantities. The current results are zero ERC errors/warnings, zero DRC violations, zero unconnected items and zero parity issues.

Those are useful CAD results, but they do not measure rail ripple, input noise, common-mode rejection, bias-loop stability, radio packet loss, runtime or electrical safety. The bench sequence above is how the project begins answering those questions. Firmware, assembled measurements and independent safety review are still pending. Do not connect electrodes to a person while charging, using the UART cable or using grounded bench instruments. This revision is not a medical device or a certified patient interface.

## Folder guide

```text
EEG/
├── README.md                 Start here
├── hardware/                 KiCad project, sheets, PCB and local libraries
├── exports/
│   ├── schematic.pdf         Readable five-page schematic
│   ├── assembly.pdf          Assembly drawing
│   ├── BOM.csv               Parts list
│   ├── EEG.net               Exported schematic connectivity
│   ├── previews/             PNG and SVG previews
│   └── fabrication/          Gerbers, drills and placement CSV
├── reports/                  ERC, DRC, connectivity audit and baseline
├── tools/                    Rebuild, validation and packaging scripts
├── releases/                 Checked ZIP packages and SHA256 checksums
└── archive/                  Previous routing attempts and local backups
```

Keep the files and local libraries inside `hardware/` together so KiCad resolves the schematic hierarchy and project libraries. Generated exports and reports are separate from editable CAD files. The archive is excluded from release packages and version control.

Run the commands below from this `EEG/` folder. Repackage the deliverables with `python tools/package_design.py` after regenerating and checking any changed exports.


## Keeping the educational figures up to date

The images above come from the actual annotated KiCad schematics. Blue callout labels such as **I1**, **F2**, **P3** and **R5** connect the prose to the drawing. They are explanatory text and do not add circuit connections. The full-page images are available in expandable sections, while the enlarged excerpts make individual circuits easier to read. These drawings document the circuit; they do not represent measured operation.

After changing the schematics, regenerate the SVGs and readable excerpts from the `EEG/` directory:

```sh
kicad-cli sch export svg -o exports/previews hardware/EEG.kicad_sch
python tools/render_schematic_previews.py
```

The rendering script requires `rsvg-convert` from librsvg. It is already installed in this workspace. Regenerate the schematic PDF and netlist, repeat the CAD checks and connectivity audit, then run the packaging script so the release contains matching files.

## Reproducibility

`hardware/design-manifest.json` records the intended components and nets. `tools/build_schematic.py` and `tools/schematic_sections.py` rebuild the readable schematics using installed KiCad symbol libraries. The routed PCB is the authoritative layout; rebuilding a schematic does not reroute it. `reports/baseline-net-map.json` preserves the checked circuit before the readability revision; the connectivity audit confirms identical nets. `tools/local_libraries.py` records the two intentional footprint variants. `tools/repair_routes.py` is an implementation helper for the analog reroute and must not be run on the finished layout without first removing the routes it replaces.

Checks can be repeated with:

```sh
kicad-cli sch erc -o reports/schematic-erc.rpt hardware/EEG.kicad_sch
kicad-cli pcb drc --schematic-parity --format json -o reports/final-drc.json hardware/EEG.kicad_pcb
python tools/validate_design.py
```


## Read the primary sources

- [TI ADS1299 family data sheet](https://www.ti.com/lit/ds/symlink/ads1299.pdf): variant pinout, capacitors, registers, timing and acquisition.
- [Espressif ESP32-C3-WROOM-02 data sheet](https://documentation.espressif.com/esp32-c3-wroom-02_datasheet_en.html): supply, GPIOs, strapping and antenna layout.
- [Diodes AP63200/AP63203 family data sheet](https://www.diodes.com/datasheet/download/AP63200-AP63201-AP63203-AP63205.pdf): buck application circuit.
- [TI LP2985-N data sheet](https://www.ti.com/lit/ds/symlink/lp2985-n.pdf): analog LDO and capacitor stability requirements.
- [Nexperia BAV199 data sheet](https://assets.nexperia.com/documents/data-sheet/BAV199.pdf): low-leakage diode pair and pin numbering.
- [Bourns SRP5030T data sheet](https://bourns.com/docs/product-datasheets/srp5030t.pdf): inductor electrical/mechanical data.

No assembled measurements, EMC tests, battery runtime, supplier availability, or clinical suitability are claimed.
